package org.sobadfish.title.manager;

import org.sobadfish.title.data.PlayerData;

import java.io.File;
import java.util.List;

/**
 * @author Sobadfish
 * @date 2022/9/15
 */
public class PlayerManager extends BaseDataWriterGetterManager<PlayerData>{

    public PlayerManager(List<PlayerData> dataList, File file) {
        super(dataList, file);
    }

    public PlayerData getData(String player){
        PlayerData data = new PlayerData(player);

        if(!dataList.contains(data)){
            dataList.add(data);
        }
        return dataList.get(dataList.indexOf(data));
    }

    public static PlayerManager asFile(File file){
        return (PlayerManager) BaseDataWriterGetterManager.asFile(file,"player.json", PlayerData[].class,PlayerManager.class);
    }
}
