package org.sobadfish.title.data;

import cn.nukkit.Player;
import cn.nukkit.Server;
import org.sobadfish.title.utils.Tools;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

/**
 * @author Sobadfish
 * @date 2022/9/15
 */
public class PlayerData {

    public String name;

    public TitleData wearTitle;

    public List<TitleData> titles = new ArrayList<>();


    public PlayerData(String name){
        this.name = name;
    }


    public void wearTitle(int index){
        if(index < titles.size()){
            wearTitle = titles.get(index);
        }
    }

    public void wearTitle(String name){
        for(TitleData titleData: titles){
            if(titleData.name.equalsIgnoreCase(name)){
                wearTitle = titleData;
                break;
            }
        }
    }

    public void wearTitle(TitleData title){
       this.wearTitle = title;
       if(!titles.contains(title)){
           titles.add(title);
       }else{
           TitleData titleData = titles.get(titles.indexOf(title));
           int time = Tools.calLastedTime(titleData.outTime);
           titleData.outTime = Tools.mathTime(time);
       }
    }

    public boolean removeTitle(String name){
        for(TitleData titleData:new ArrayList<>(titles)){
            if(titleData.name.equalsIgnoreCase(name)){
                if(wearTitle.equals(titleData)){
                    wearTitle = null;
                }
                titles.remove(titleData);
            }
        }
        return false;
    }

    public Player getPlayer(){
        return Server.getInstance().getPlayer(name);
    }

    /**
     * 移除过期的称号
     * */
    public void deleteTimeOut(){
        for(TitleData titleData:new ArrayList<>(titles)){
            if(titleData.outTime == null || "".equalsIgnoreCase(titleData.outTime)){
                continue;
            }
            if(Tools.isOut(titleData.outTime)){
                if(wearTitle != null && wearTitle.equals(titleData)){
                    wearTitle = null;
                }
                titles.remove(titleData);

            }
        }
    }

    public static class TitleData{

        /**
         * 称号名称
         * */
        public String name;

        /**
         * 称号到期时间
         * */
        public String outTime;

        /**
         * 称号执行指令
         * */
        public String cmd;

        /**
         * 称号执行指令延迟
         * */
        public int delay;

        public TitleData(String name,String outTime,String cmd,int delay){
            this.name = name;
            this.outTime = outTime;
            this.cmd = cmd;
            this.delay = delay;
        }

        public TitleData(String name,int sec,String cmd,int delay){
            this.name = name;
            this.outTime = Tools.mathTime(sec);
            this.cmd = cmd;
            this.delay = delay;
        }

        @Override
        public boolean equals(Object o) {
            if (this == o) {
                return true;
            }
            if (o == null || getClass() != o.getClass()) {
                return false;
            }
            TitleData titleData = (TitleData) o;
            return name.equals(titleData.name);
        }

        @Override
        public int hashCode() {
            return Objects.hash(name);
        }
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        PlayerData that = (PlayerData) o;
        return name.equals(that.name);
    }

    @Override
    public int hashCode() {
        return Objects.hash(name);
    }
}
